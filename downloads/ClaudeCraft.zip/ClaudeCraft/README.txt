ClaudeCraft
===========

A Minecraft-inspired voxel sandbox game, written from scratch in JavaScript
and WebGL2. No installation needed.

HOW TO PLAY
-----------
Windows:  double-click ClaudeCraft.exe
          (it opens the game in a Microsoft Edge / Chrome app window).
          If Windows SmartScreen warns about an unknown publisher, click
          "More info" -> "Run anyway" (the launcher is not code-signed).
Any OS:   double-click ClaudeCraft.html to play it in your web browser
          (Chrome, Edge or Firefox recommended).

CONTROLS
--------
WASD            move              Mouse          look around
Space           jump / swim       Shift          sneak / fly down
Ctrl or W-W     sprint            Space-Space    fly (Creative)
Left click      break block       Right click    place block / use table
Middle click    pick block        1-9 / wheel    choose hotbar slot
E               inventory         F3             debug info
Esc             pause menu        F1             hide HUD

Your worlds are saved automatically in the browser.

Source code: https://github.com/Jeep200092919/Minecraft-Claude-Version
